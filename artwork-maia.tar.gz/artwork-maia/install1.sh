#!/bin/bash

# Verificar si se está ejecutando como root
if [[ $(id -u) -ne 0 ]]; then
    echo "Este script debe ser ejecutado como root. Usa 'sudo'."
    exit 1
fi

# Ruta de origen
origen="/artwork-maia"

# Copiar archivos y carpetas
sudo cp "$origen/colors/{Maia.colors,MaiaDark.colors}" /usr/share/color-schemes/
sudo cp -r "$origen/desktoptheme/maia" /usr/share/plasma/desktoptheme/
sudo cp -r "$origen/icons/{maia,maia-dark}" /usr/share/icons/
sudo cp "$origen/kservices5/{plasma-lookandfeel-org.kde.maia.desktop.desktop,plasma-lookandfeel-org.kde.maiadark.desktop.desktop}" /usr/share/kservices5/
sudo cp -r "$origen/lookandfeel/{org.kde.maia.desktop,org.kde.maiadark}" /usr/share/plasma/look-and-feel/
sudo cp "$origen/metainfo/{org.kde.maia.desktop.appdata.xml,org.kde.maiadark.desktop.appdata.xml}" /usr/share/metainfo/
sudo cp -r "$origen/sddm/maia" /usr/share/sddm/themes/
sudo cp -r "$origen/wallpapers/Maia" /usr/share/wallpapers/

# Mensaje de instalación completada
echo "La instalación del tema Maia se ha completado correctamente."