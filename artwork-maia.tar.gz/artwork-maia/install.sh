#!/bin/bash

sudo cp /artwork-maia/colors/{Maia.colors,MaiaDark.colors} /usr/share/color-schemes/
sudo cp -r /artwork-maia/desktoptheme/maia /usr/share/plasma/desktoptheme/
sudo cp -r /artwork-maia/icons/{maia,maia-dark} /usr/share/icons/
sudo cp /artwork-maia/kservices5/{plasma-lookandfeel-org.kde.maia.desktop.desktop,plasma-lookandfeel-org.kde.maiadark.desktop.desktop} /usr/share/kservices5/
sudo cp -r /artwork-maia/lookandfeel/{org.kde.maia.desktop,org.kde.maiadark} /usr/share/plasma/look-and-feel/
sudo cp /artwork-maia/metainfo/{org.kde.maia.desktop.appdata.xml,org.kde.maiadark.desktop.appdata.xml} /usr/share/metainfo/
sudo cp -r /artwork-maia/sddm/maia /usr/share/sddm/themes/
sudo cp -r /artwork-maia/wallpapers/Maia /usr/share/wallpapers/